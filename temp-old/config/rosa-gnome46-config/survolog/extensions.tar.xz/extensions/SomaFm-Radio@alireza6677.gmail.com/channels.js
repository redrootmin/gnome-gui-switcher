import GObject from "gi://GObject";
import Gio from "gi://Gio";
import St from "gi://St";
import Clutter from "gi://Clutter";

import * as PopupMenu from "resource:///org/gnome/shell/ui/popupMenu.js";

import * as Data from "./data.js";
import { extPath } from "./extension.js";

export const channels = [
    {
        name: "Вести ФМ",
        link: "http://icecast.vgtrk.cdnvideo.ru/vestifm_mp3_128kbps",
        pic: "/images/vestifm.jpg",
        num: 0,
    },
    {
        name: "Маруся ФМ",
        link: "http://radio-holding.ru:9000/marusya_default",
        pic: "/images/marusyafm.jpg",
        num: 1,
    },
    {
        name: "Русское Радио",
        link: "https://rusradio.hostingradio.ru/rusradio96.aacp",
        pic: "/images/rusradio.jpg",
        num: 2,
    },
    {
        name: "Радио Кавказ Хит",
        link: "https://kavkazhit.hostingradio.ru:8017/kavkazhit96.mp3",
        pic: "/images/kavkaz-hit.jpg",
        num: 3,
    },
    {
        name: "Радио Маяк",
        link: "http://icecast.vgtrk.cdnvideo.ru/mayakfm_mp3_128kbps",
        pic: "/images/radiomayak.jpg",
        num: 4,
    },
    {
        name: "Радио Рекорд",
        link: "https://radiorecord.hostingradio.ru/rr_main96.aacp",
        pic: "/images/radiorecod.jpg",
        num: 5,
    },
    {
        name: "Rock - Радио Рекорд",
        link: "https://radiorecord.hostingradio.ru/rock96.aacp",
        pic: "/images/rekord-rock.jpg",
        num: 6,
    },
    {
        name: "Милицейская Волна",
        link: "https://radiomv.hostingradio.ru:80/radiomv256.mp3",
        pic: "/images/radiomv.jpg",
        num: 7,
    },
    {
        name: "Шансон радио",
        link: "https://listen7.myradio24.com/75853",
        pic: "/images/shanson-radio.jpg",
        num: 8,
    },
];

const holidayChannels = [
    {
        name: "Русское Радио: Зимнее Любимое",
        link: "https://rr-zimlub.hostingradio.ru/zimlub96.aacp",
        pic: "/images/rusradiozimlubimoe.jpg",
        num: 9,
    },
];

export const Channel = class Channel {
    constructor(name, link, pic, num, fav) {
        this.name = name;
        this.link = link;
        this.pic = pic;
        this.num = num;
        this.fav = fav;
    }

    getName() {
        return this.name;
    }

    getLink() {
        return this.link;
    }

    getPic() {
        return this.pic;
    }

    getNum() {
        return this.num;
    }

    isFav() {
        return this.fav;
    }

    setFav(f) {
        this.fav = f;
    }
};

export const ChannelBox = GObject.registerClass(
    class ChannelBox extends PopupMenu.PopupBaseMenuItem {
        _init(channel, player, popup) {
            super._init({
                reactive: true,
                can_focus: true,
            });
            this.player = player;
            this.channel = channel;
            this.popup = popup;

            this.vbox = new St.BoxLayout({ vertical: false });
            this.add_child(this.vbox);

            let icon2 = new St.Icon({
                gicon: Gio.icon_new_for_string(extPath + channel.getPic()),
                style: "margin-right:10px",
                icon_size: 60,
            });

            let box2 = new St.BoxLayout({ vertical: false });
            let label1 = new St.Label({
                text: channel.getName(),
                y_align: Clutter.ActorAlign.CENTER,
                y_expand: true,
            });
            this.vbox.add_child(icon2);
            this.vbox.add_child(box2);
            box2.add_child(label1);
        }

        activate(ev) {
            this.player.stop();
            this.player.setChannel(this.channel);
            this.player.play();
            this.popup.channelChanged();
        }
    },
);

export function getChannels() {
    const isDecember = new Date().getMonth() === 11;
    const allChannels = isDecember ? [...channels, ...holidayChannels] : channels;

    return allChannels.map(
        (ch) => new Channel(ch.name, ch.link, ch.pic, ch.num, Data.isFav(ch.num)),
    );
}

export function getFavChannels() {
    return getChannels()
        .filter((ch) => Data.isFav(ch.num))
        .map((ch) => new Channel(ch.name, ch.link, ch.pic, ch.num, true));
}

export function getChannel(index) {
    let item = getChannels()[index] ?? getChannels()[0];
    return new Channel(
        item.name,
        item.link,
        item.pic,
        item.num,
        Data.isFav(item.num),
    );
}
