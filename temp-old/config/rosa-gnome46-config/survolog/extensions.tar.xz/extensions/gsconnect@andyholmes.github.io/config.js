// SPDX-FileCopyrightText: GSConnect Developers https://github.com/GSConnect
//
// SPDX-License-Identifier: GPL-2.0-or-later

var PACKAGE_VERSION = 56;
var PACKAGE_URL = 'https://github.com/GSConnect/gnome-shell-extension-gsconnect';
var PACKAGE_BUGREPORT = 'https://github.com/GSConnect/gnome-shell-extension-gsconnect/issues/new';
var PACKAGE_DATADIR = '/usr/share/gnome-shell/extensions/gsconnect@andyholmes.github.io';
var PACKAGE_LOCALEDIR = '/usr/share/locale';
var GSETTINGS_SCHEMA_DIR = '/usr/share/glib-2.0/schemas';
var GNOME_SHELL_LIBDIR = '/usr/lib64/';

var APP_ID = 'org.gnome.Shell.Extensions.GSConnect';
var APP_PATH = '/org/gnome/Shell/Extensions/GSConnect';

var IS_USER = false;

// External binary paths
var OPENSSL_PATH = 'openssl';
var SSHADD_PATH = 'ssh-add';
var SSHKEYGEN_PATH = 'ssh-keygen';
var FFMPEG_PATH = 'ffmpeg';
